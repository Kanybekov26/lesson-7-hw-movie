export let stayleDel = {
  backgroundColor: "brown",
  width: "130px",
  height: "40px",
  borderRadius: "10px",
  border: "none",
  marginLeft: "20px",
  marginTop: "17px",
  color:" aliceblue",
  
};


export let stayleEd = {
    color: "aliceblue",

    backgroundColor:" rgb(63, 42, 165)" ,
    width: "100px",
    height:" 40px",
    borderRadius: "10px",
    border: "none",
    marginLeft: "20px",
     marginTop: "17px",
}

export let stayleEdd = {
    backgroundColor: "chocolate",
    color: "aliceblue",

    width: "100px",
    height:" 40px",
    borderRadius: "10px",
    border: "none",
    marginLeft: "20px",
     marginTop: "17px",
}