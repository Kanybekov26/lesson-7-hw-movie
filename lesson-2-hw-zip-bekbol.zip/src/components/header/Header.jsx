import React from 'react'
import Button from '../button/Button'
import "./Header.css"
import { stayleEdd } from '../color/stayl'
const Header = () => {
  return (
    <div className='header-Container'>
        <div className='text-button-container'>
        <h1 className='h1'>Foverite Movies</h1> 
        <Button 
        color={stayleEdd}
        ButtonText={"ADD MOVIE"}
        />
        </div>
       
        </div>
  )
}

export default Header