import React from "react";
import Button from "../button/Button";
import "./Movie.css";
import { stayleDel, stayleEd } from "../color/stayl";
// import { stayleEd } from "../color/stayl";
export const MovieItem = (props) => {
  console.log(props);

  let { MoviesItem } = props;
  // console.log(MoviesItem);

  return MoviesItem.map((element,index) => {
    return (
      <div className="div" key={index}>
        <div className="main-container" >
          <div className="img-container" >
            <img className="img" src={element.img} alt="kjnjnkk" />
          </div>

          <div>
            <h2>{element.title}</h2>
            <div className="button-container">
              <div className="text-container">
                <p className="stars">{element.rating}/5stars</p>
                <Button 
                color={stayleDel}
            ButtonText={"DELETE"}
          />
          <Button
           color={stayleEd}
          ButtonText={"EDIT"}
          />

                <div className="button-container">
                  {/* <button className="button-Del">vdsvs</button>
                  <button className="button-Ed">vdsv</button> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  });
};
