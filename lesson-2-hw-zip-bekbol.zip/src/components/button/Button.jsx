import React from 'react'
import "./Button.css"
const Button = (props) => {
  let { color,  ButtonText} = props
  return (
    <div className='button-container'>
        <button style={color}>{ButtonText}</button>
    </div>
  )
}

export default Button